import { NavLink, Route, Routes } from 'react-router-dom';
import HomePage from './components/HomePage';
import MovieTablePage from './components/MovieTablePage';
import FavoriteMoviePage from './components/FavoriteMoviePage';
import TestingPage from './testing/TestingPage';

const links = [
  { to: '/', label: 'Главная' },
  { to: '/movies', label: 'Список фильмов' },
  { to: '/favorite', label: 'Избранный фильм' },
  { to: '/testing', label: 'Проверь себя' }
];

function App() {
  return (
    <div className="app">
      <header className="header">
        <NavLink className="logo" to="/">
          Кинотека
        </NavLink>
        <nav className="nav" aria-label="Главная навигация">
          {links.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              className={({ isActive }) => `nav__link${isActive ? ' nav__link_active' : ''}`}
            >
              {link.label}
            </NavLink>
          ))}
        </nav>
      </header>

      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/movies" element={<MovieTablePage />} />
        <Route path="/favorite" element={<FavoriteMoviePage />} />
        <Route path="/testing" element={<TestingPage />} />
      </Routes>

      <footer className="footer">
        <div>
          <strong>Кинотека</strong>
          <p>Учебное web-приложение по предметной области «Фильмы».</p>
        </div>
        <nav className="footer__nav" aria-label="Навигация в футере">
          {links.map((link) => (
            <NavLink key={link.to} to={link.to}>
              {link.label}
            </NavLink>
          ))}
        </nav>
      </footer>
    </div>
  );
}

export default App;
