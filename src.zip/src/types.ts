export type Page = 'home' | 'table' | 'favorite';

export interface Movie {
  id: number;
  title: string;
  year: number;
  genre: string;
  director: string;
  country: string;
  rating: number;
  duration: string;
}

export interface PromoMovie {
  title: string;
  year?: number;
  text: string;
  image: string;
}
