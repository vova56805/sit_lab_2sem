import { sidebarMovies } from '../data.ts';

function Sidebar() {
  return (
    <aside className="sidebar" aria-label="Правый блок">
      <div className="sidebar__list">
        {sidebarMovies.map((movie) => (
          <article className="side-item" key={movie.title}>
            <div className="side-item__content">
              <h3 className="side-item__title">
                {movie.title} {movie.year ? `(${movie.year})` : ''}
              </h3>
              <div className="side-item__text">
                <p>{movie.text}</p>
                <a className="btn" href="#table">Подробнее</a>
              </div>
            </div>

            <div className="img-circle side-item__img">
              <img src={movie.image} alt={movie.title} />
            </div>
          </article>
        ))}
      </div>
    </aside>
  );
}

export default Sidebar;
