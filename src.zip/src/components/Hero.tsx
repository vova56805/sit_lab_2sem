import { heroImages } from '../data';

function Hero() {
  return (
    <section className="hero" aria-label="Верхний блок с постерами">
      <div className="hero__row">
        <a className="img-box hero__big" href="#favorite">
          <img src={heroImages.main} alt="Кадр из фильма" />
        </a>

        <div className="hero__side">
          <div className="img-box hero__sideTop">
            <img src={heroImages.sideTop} alt="Кинопостер" />
          </div>
          <div className="img-box hero__sideBottom">
            <img src={heroImages.sideBottom} alt="Постер Звёздные войны" />
          </div>
        </div>
      </div>

      <div className="img-box hero__wide">
        <img src={heroImages.wide} alt="Широкий постер" />
      </div>
    </section>
  );
}

export default Hero;
