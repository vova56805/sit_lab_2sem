import { favoriteMovie } from '../data';

function FavoriteMoviePage() {
  return (
    <main className="single-page">
      <section className="favorite-card">
        <div className="favorite-card__poster">
          <img src={favoriteMovie.image} alt={favoriteMovie.title} />
        </div>

        <div className="favorite-card__content">
          <p className="eyebrow">Избранное</p>
          <h1>{favoriteMovie.title}</h1>
          <h2>{favoriteMovie.originalTitle}</h2>

          {favoriteMovie.paragraphs.map((paragraph) => (
            <p key={paragraph}>{paragraph}</p>
          ))}

          <ul className="facts-list">
            {favoriteMovie.facts.map((fact) => (
              <li key={fact}>{fact}</li>
            ))}
          </ul>
        </div>
      </section>
    </main>
  );
}

export default FavoriteMoviePage;
