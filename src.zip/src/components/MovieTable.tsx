import Container from '@mui/material/Container';
import { DataGrid, GridColDef, GridRowsProp } from '@mui/x-data-grid';
import { ruRU } from '@mui/x-data-grid/locales';
import { movies } from '../data';

function MovieTable() {
  const rows: GridRowsProp = movies.map((movie) => ({
    id: movie.id,
    'Название фильма': movie.title,
    'Год': movie.year,
    'Жанр': movie.genre,
    'Режиссёр': movie.director,
    'Страна': movie.country,
    'Рейтинг IMDb': movie.rating,
    'Длительность': movie.duration
  }));

  const columns: GridColDef[] = [
    { field: 'Название фильма', headerName: 'Название фильма', flex: 1.2 },
    { field: 'Год', type: 'number', flex: 0.35 },
    { field: 'Жанр', flex: 0.8 },
    { field: 'Режиссёр', flex: 0.8 },
    { field: 'Страна', flex: 0.7 },
    { field: 'Рейтинг IMDb', type: 'number', flex: 0.45 },
    { field: 'Длительность', flex: 0.45 }
  ];

  return (
    <Container maxWidth="lg" sx={{ height: '700px', mt: '20px' }}>
      <DataGrid
        localeText={ruRU.components.MuiDataGrid.defaultProps.localeText}
        rows={rows}
        columns={columns}
        showToolbar={true}
        initialState={{
          pagination: {
            paginationModel: { page: 0, pageSize: 10 }
          }
        }}
        pageSizeOptions={[10, 25, 50, 100]}
      />
    </Container>
  );
}

export default MovieTable;
