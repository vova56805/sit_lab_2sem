import Hero from './Hero';
import Sidebar from './Sidebar';
import { mainFeature, premiereFeature } from '../data';

function HomePage() {
  return (
    <>
      <Hero />

      <main className="main">
        <section className="content">
          <h1 className="section-title">{mainFeature.title}</h1>

          <div className="content__row">
            <div className="content__texts">
              <article className="text-block">
                <div className="text-block__lines">
                  <p>{mainFeature.paragraphs[0]}</p>
                </div>
              </article>

              <article className="text-block">
                <div className="text-block__lines">
                  <p>{mainFeature.paragraphs[1]}</p>
                  <a className="btn_2" href="#table">Подробнее</a>
                </div>
              </article>
            </div>

            <div className="img-box content__img">
              <img src={mainFeature.image} alt={mainFeature.title} />
            </div>
          </div>

          <section className="feature">
            <h2 className="feature__title">{premiereFeature.title}</h2>

            <div className="feature__inner">
              <div className="img-box feature__img">
                <img src={premiereFeature.image} alt="Бойцовский клуб" />
              </div>

              <div className="feature__text">
                <div className="text-block__lines">
                  <p>{premiereFeature.text}</p>
                  <a className="btn" href="#table">Подробнее</a>
                </div>
              </div>
            </div>
          </section>
        </section>

        <Sidebar />
      </main>
    </>
  );
}

export default HomePage;
