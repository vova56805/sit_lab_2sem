import MovieTable from './MovieTable';

function MovieTablePage() {
  return (
    <main className="table-page">
      <MovieTable />
    </main>
  );
}

export default MovieTablePage;
