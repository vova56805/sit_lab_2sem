import MovieTable from './MovieTable.tsx';

function MovieTablePage() {
  return (
    <main className="table-page">
      <MovieTable />
    </main>
  );
}

export default MovieTablePage;
