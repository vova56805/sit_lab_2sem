export type MatchingTask = {
  id: number;
  type: 'matching';
  title: string;
  pairs: {
    question: string;
    answer: string;
  }[];
};

export type SortingTask = {
  id: number;
  type: 'sorting';
  title: string;
  items: {
    text: string;
    order: number;
  }[];
};

export type ChoiceTask = {
  id: number;
  type: 'single' | 'multiple';
  title: string;
  question: string;
  options: string[];
  correctAnswers: string[];
};

export type QuizTask = MatchingTask | SortingTask | ChoiceTask;

export const quiz: QuizTask[] = [
  {
    id: 1,
    type: 'matching',
    title: 'Сопоставьте фильм и режиссёра.',
    pairs: [
      { question: 'Титаник', answer: 'Джеймс Кэмерон' },
      { question: 'Крёстный отец', answer: 'Фрэнсис Форд Коппола' },
      { question: 'Начало', answer: 'Кристофер Нолан' },
      { question: 'Форрест Гамп', answer: 'Роберт Земекис' }
    ]
  },
  {
    id: 2,
    type: 'matching',
    title: 'Сопоставьте фильм и жанр.',
    pairs: [
      { question: 'Звёздные войны: Новая надежда', answer: 'Фантастика' },
      { question: 'Король Лев', answer: 'Анимация' },
      { question: 'Побег из Шоушенка', answer: 'Драма' },
      { question: 'Один дома', answer: 'Комедия' }
    ]
  },
  {
    id: 3,
    type: 'sorting',
    title: 'Расположите фильмы по году выхода: от более раннего к более позднему.',
    items: [
      { text: 'Крёстный отец', order: 1 },
      { text: 'Звёздные войны: Новая надежда', order: 2 },
      { text: 'Форрест Гамп', order: 3 },
      { text: 'Титаник', order: 4 },
      { text: 'Начало', order: 5 }
    ]
  },
  {
    id: 4,
    type: 'sorting',
    title: 'Расположите этапы работы с фильмом на сайте в правильном порядке.',
    items: [
      { text: 'Выбрать фильм из списка', order: 1 },
      { text: 'Открыть карточку фильма', order: 2 },
      { text: 'Изучить описание и характеристики', order: 3 },
      { text: 'Сравнить фильм с другими фильмами', order: 4 },
      { text: 'Сделать вывод о фильме', order: 5 }
    ]
  },
  {
    id: 5,
    type: 'single',
    title: 'Выберите один правильный ответ.',
    question: 'Какой фильм снял Кристофер Нолан?',
    options: ['Начало', 'Титаник', 'Король Лев', 'Один дома'],
    correctAnswers: ['Начало']
  },
  {
    id: 6,
    type: 'multiple',
    title: 'Выберите несколько правильных ответов.',
    question: 'Какие из перечисленных фильмов относятся к фантастике или научной фантастике?',
    options: ['Звёздные войны: Новая надежда', 'Начало', 'Один дома', 'Форрест Гамп'],
    correctAnswers: ['Звёздные войны: Новая надежда', 'Начало']
  }
];
