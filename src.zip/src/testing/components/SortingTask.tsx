import SortableList from './SortableList';

type SortingTaskProps = {
  items: string[];
  onChange: (items: string[]) => void;
};

function SortingTask({ items, onChange }: SortingTaskProps) {
  return <SortableList items={items} onChange={onChange} />;
}

export default SortingTask;
