import * as React from 'react';
import Checkbox from '@mui/material/Checkbox';
import FormControl from '@mui/material/FormControl';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormGroup from '@mui/material/FormGroup';
import FormLabel from '@mui/material/FormLabel';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import { ChoiceTask } from '../quizData';

interface ComponentProps {
  task: ChoiceTask;
  value: string[];
  onChange: (value: string[]) => void;
}

function Choice({ task, value, onChange }: ComponentProps) {
  if (task.type === 'single') {
    return (
      <FormControl>
        <FormLabel>{task.question}</FormLabel>
        <RadioGroup value={value[0] || ''} onChange={(event) => onChange([event.target.value])}>
          {task.options.map((option) => (
            <FormControlLabel key={option} value={option} control={<Radio />} label={option} />
          ))}
        </RadioGroup>
      </FormControl>
    );
  }

  const handleCheckbox = (option: string) => (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.checked) {
      onChange([...value, option]);
    } else {
      onChange(value.filter((item) => item !== option));
    }
  };

  return (
    <FormControl component="fieldset">
      <FormLabel component="legend">{task.question}</FormLabel>
      <FormGroup>
        {task.options.map((option) => (
          <FormControlLabel
            key={option}
            control={<Checkbox checked={value.includes(option)} onChange={handleCheckbox(option)} />}
            label={option}
          />
        ))}
      </FormGroup>
    </FormControl>
  );
}

export default Choice;
