import Box from '@mui/material/Box';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemText from '@mui/material/ListItemText';
import Typography from '@mui/material/Typography';
import { MatchingTask } from '../quizData';
import SortableList from './SortableList';

interface ComponentProps {
  task: MatchingTask;
  answers: string[];
  onChange: (answers: string[]) => void;
}

function Matching({ task, answers, onChange }: ComponentProps) {
  return (
    <Box
      sx={{
        display: 'grid',
        gridTemplateColumns: { xs: '1fr', md: '1fr 1fr' },
        gap: 3
      }}
    >
      <Box>
        <Typography variant="subtitle2" color="text.secondary" sx={{ mb: 1 }}>
          Вопросы
        </Typography>
        <List sx={{ p: 0 }}>
          {task.pairs.map((item, index) => (
            <ListItem key={`${item.question}-${index}`} disablePadding sx={{ mb: 1.5 }}>
              <ListItemButton
                sx={{
                  border: '1px solid gray',
                  borderRadius: '5px',
                  textAlign: 'right',
                  bgcolor: 'background.paper'
                }}
              >
                <ListItemText primary={item.question} />
              </ListItemButton>
            </ListItem>
          ))}
        </List>
      </Box>

      <Box>
        <Typography variant="subtitle2" color="text.secondary" sx={{ mb: 1 }}>
          Ответы
        </Typography>
        <SortableList items={answers} onChange={onChange} />
      </Box>
    </Box>
  );
}

export default Matching;
