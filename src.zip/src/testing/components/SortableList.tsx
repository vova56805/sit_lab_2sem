import { closestCenter, DndContext, DragEndEvent } from '@dnd-kit/core';
import { arrayMove, SortableContext, verticalListSortingStrategy } from '@dnd-kit/sortable';
import { List } from '@mui/material';
import SortableItem from './SortableItem';

type SortableListProps = {
  items: string[];
  onChange: (items: string[]) => void;
};

function SortableList({ items, onChange }: SortableListProps) {
  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;

    if (!over || active.id === over.id) {
      return;
    }

    const oldIndex = items.indexOf(String(active.id));
    const newIndex = items.indexOf(String(over.id));

    if (oldIndex !== -1 && newIndex !== -1) {
      onChange(arrayMove(items, oldIndex, newIndex));
    }
  };

  return (
    <DndContext collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
      <SortableContext items={items} strategy={verticalListSortingStrategy}>
        <List disablePadding>
          {items.map((item) => (
            <SortableItem key={item} id={item} />
          ))}
        </List>
      </SortableContext>
    </DndContext>
  );
}

export default SortableList;
