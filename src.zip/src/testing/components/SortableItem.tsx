import DragIndicatorIcon from '@mui/icons-material/DragIndicator';
import { ListItem, ListItemButton, ListItemIcon, ListItemText } from '@mui/material';
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';

type SortableItemProps = {
  id: string;
};

function SortableItem({ id }: SortableItemProps) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.55 : 1,
    zIndex: isDragging ? 10 : 'auto'
  };

  return (
    <ListItem ref={setNodeRef} style={style} disablePadding sx={{ mb: 1 }} {...attributes} {...listeners}>
      <ListItemButton className="quiz-card quiz-card_answer">
        <ListItemIcon sx={{ minWidth: 34 }}>
          <DragIndicatorIcon fontSize="small" />
        </ListItemIcon>
        <ListItemText primary={id} />
      </ListItemButton>
    </ListItem>
  );
}

export default SortableItem;
