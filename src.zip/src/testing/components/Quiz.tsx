import * as React from 'react';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Container from '@mui/material/Container';
import Paper from '@mui/material/Paper';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import Choice from './Choice';
import Matching from './Matching';
import Sorting from './Sorting';
import { quiz } from '../quizData';

function shuffleArray<T>(array: T[]): T[] {
  const result = [...array];

  for (let i = result.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [result[i], result[j]] = [result[j], result[i]];
  }

  return result;
}

function isEqualSets(first: string[], second: string[]) {
  if (first.length !== second.length) {
    return false;
  }

  const firstSorted = [...first].sort();
  const secondSorted = [...second].sort();

  return firstSorted.every((item, index) => item === secondSorted[index]);
}

type Result = {
  id: number;
  title: string;
  correct: number;
  total: number;
};

function Quiz() {
  const [matchingAnswers, setMatchingAnswers] = React.useState<Record<number, string[]>>({});
  const [sortingAnswers, setSortingAnswers] = React.useState<Record<number, string[]>>({});
  const [choiceAnswers, setChoiceAnswers] = React.useState<Record<number, string[]>>({});
  const [results, setResults] = React.useState<Result[] | null>(null);

  const prepareTest = React.useCallback(() => {
    const matching: Record<number, string[]> = {};
    const sorting: Record<number, string[]> = {};
    const choice: Record<number, string[]> = {};

    quiz.forEach((task) => {
      if (task.type === 'matching') {
        matching[task.id] = shuffleArray(task.pairs.map((pair) => pair.answer));
      }

      if (task.type === 'sorting') {
        sorting[task.id] = shuffleArray(task.items.map((item) => item.text));
      }

      if (task.type === 'single' || task.type === 'multiple') {
        choice[task.id] = [];
      }
    });

    setMatchingAnswers(matching);
    setSortingAnswers(sorting);
    setChoiceAnswers(choice);
    setResults(null);
  }, []);

  React.useEffect(() => {
    prepareTest();
  }, [prepareTest]);

  const checkTest = () => {
    const currentResults: Result[] = quiz.map((task) => {
      if (task.type === 'matching') {
        const answers = matchingAnswers[task.id] || [];
        const correct = task.pairs.reduce((count, pair, index) => {
          return count + (answers[index] === pair.answer ? 1 : 0);
        }, 0);

        return {
          id: task.id,
          title: task.title,
          correct,
          total: task.pairs.length
        };
      }

      if (task.type === 'sorting') {
        const answers = sortingAnswers[task.id] || [];
        const correctOrder = [...task.items]
          .sort((first, second) => first.order - second.order)
          .map((item) => item.text);
        const correct = correctOrder.reduce((count, item, index) => {
          return count + (answers[index] === item ? 1 : 0);
        }, 0);

        return {
          id: task.id,
          title: task.title,
          correct,
          total: correctOrder.length
        };
      }

      const selected = choiceAnswers[task.id] || [];
      const correct = isEqualSets(selected, task.correctAnswers) ? 1 : 0;

      return {
        id: task.id,
        title: task.title,
        correct,
        total: 1
      };
    });

    setResults(currentResults);
  };

  return (
    <Container maxWidth="md" sx={{ py: 4 }}>
      <Typography
        variant="h4"
        component="h1"
        align="center"
        sx={{ mb: 3, color: '#5d8aa8', fontWeight: 700 }}
      >
        Проверь себя
      </Typography>

      <Stack spacing={3}>
        {quiz.map((task, index) => (
          <Paper key={task.id} component="section" sx={{ p: { xs: 2, md: 3 } }} variant="outlined">
            <Typography variant="h5" gutterBottom>
              {index + 1}. {task.title}
            </Typography>

            {task.type === 'matching' && (
              <Matching
                task={task}
                answers={matchingAnswers[task.id] || []}
                onChange={(answers) =>
                  setMatchingAnswers((prev) => ({
                    ...prev,
                    [task.id]: answers
                  }))
                }
              />
            )}

            {task.type === 'sorting' && (
              <Sorting
                items={sortingAnswers[task.id] || []}
                onChange={(items) =>
                  setSortingAnswers((prev) => ({
                    ...prev,
                    [task.id]: items
                  }))
                }
              />
            )}

            {(task.type === 'single' || task.type === 'multiple') && (
              <Choice
                task={task}
                value={choiceAnswers[task.id] || []}
                onChange={(value) =>
                  setChoiceAnswers((prev) => ({
                    ...prev,
                    [task.id]: value
                  }))
                }
              />
            )}
          </Paper>
        ))}
      </Stack>

      <Box sx={{ display: 'flex', justifyContent: 'space-around', gap: 2, my: 4 }}>
        <Button variant="contained" color="info" onClick={checkTest}>
          Проверить
        </Button>
        <Button variant="contained" color="info" onClick={prepareTest}>
          Начать снова
        </Button>
      </Box>

      {results && (
        <Paper sx={{ p: 3, mb: 4 }} variant="outlined">
          <Typography variant="h5" align="center" gutterBottom>
            Результаты теста
          </Typography>

          {results.map((item, index) => (
            <Typography key={item.id} align="center" sx={{ mb: 0.5 }}>
              Задание {index + 1}. Верных ответов: {item.correct} из {item.total}.
            </Typography>
          ))}
        </Paper>
      )}
    </Container>
  );
}

export default Quiz;
