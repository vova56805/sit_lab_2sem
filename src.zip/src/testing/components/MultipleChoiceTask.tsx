import { Checkbox, FormControlLabel, Stack } from '@mui/material';
import type { MultipleChoiceQuestion } from '../quizData';

type MultipleChoiceTaskProps = {
  question: MultipleChoiceQuestion;
  value: string[];
  onChange: (value: string[]) => void;
};

function MultipleChoiceTask({ question, value, onChange }: MultipleChoiceTaskProps) {
  const toggleValue = (option: string) => {
    if (value.includes(option)) {
      onChange(value.filter((item) => item !== option));
      return;
    }

    onChange([...value, option]);
  };

  return (
    <Stack>
      {question.options.map((option) => (
        <FormControlLabel
          key={option}
          control={<Checkbox checked={value.includes(option)} onChange={() => toggleValue(option)} />}
          label={option}
        />
      ))}
    </Stack>
  );
}

export default MultipleChoiceTask;
