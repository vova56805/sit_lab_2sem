import { Box, List, ListItem, ListItemButton, ListItemText } from '@mui/material';
import type { MatchingQuestion } from '../quizData';
import SortableList from './SortableList';

type MatchingTaskProps = {
  question: MatchingQuestion;
  answers: string[];
  onChange: (items: string[]) => void;
};

function MatchingTask({ question, answers, onChange }: MatchingTaskProps) {
  return (
    <Box className="matching-grid">
      <List disablePadding>
        {question.pairs.map((pair) => (
          <ListItem key={pair.left} disablePadding sx={{ mb: 1 }}>
            <ListItemButton className="quiz-card quiz-card_question">
              <ListItemText primary={pair.left} />
            </ListItemButton>
          </ListItem>
        ))}
      </List>

      <SortableList items={answers} onChange={onChange} />
    </Box>
  );
}

export default MatchingTask;
