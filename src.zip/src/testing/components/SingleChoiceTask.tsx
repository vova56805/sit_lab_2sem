import { FormControl, FormControlLabel, Radio, RadioGroup } from '@mui/material';
import type { SingleChoiceQuestion } from '../quizData';

type SingleChoiceTaskProps = {
  question: SingleChoiceQuestion;
  value: string;
  onChange: (value: string) => void;
};

function SingleChoiceTask({ question, value, onChange }: SingleChoiceTaskProps) {
  return (
    <FormControl fullWidth>
      <RadioGroup value={value} onChange={(event) => onChange(event.target.value)}>
        {question.options.map((option) => (
          <FormControlLabel key={option} value={option} control={<Radio />} label={option} />
        ))}
      </RadioGroup>
    </FormControl>
  );
}

export default SingleChoiceTask;
