import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import SortableList from './SortableList';

interface ComponentProps {
  items: string[];
  onChange: (items: string[]) => void;
}

function Sorting({ items, onChange }: ComponentProps) {
  return (
    <Box>
      <Typography variant="subtitle2" color="text.secondary" sx={{ mb: 1 }}>
        Перетащите элементы в правильный порядок
      </Typography>
      <SortableList items={items} onChange={onChange} />
    </Box>
  );
}

export default Sorting;
