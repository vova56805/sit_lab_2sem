import { useMemo, useState } from 'react';
import { Box, Button, Container, Paper, Stack, Typography } from '@mui/material';
import MatchingTask from './components/MatchingTask';
import SortingTask from './components/SortingTask';
import SingleChoiceTask from './components/SingleChoiceTask';
import MultipleChoiceTask from './components/MultipleChoiceTask';
import { quiz } from './quizData';
import type { MatchingQuestion, SortingQuestion } from './quizData';

type AnswersState = Record<number, string[]>;
type SingleState = Record<number, string>;
type ResultsState = Record<number, number>;

function shuffle<T>(items: T[]): T[] {
  return [...items].sort(() => Math.random() - 0.5);
}

function createDragState() {
  const matching: AnswersState = {};
  const sorting: AnswersState = {};

  quiz.forEach((question) => {
    if (question.type === 'matching') {
      matching[question.id] = shuffle(question.pairs.map((pair) => pair.right));
    }

    if (question.type === 'sorting') {
      sorting[question.id] = shuffle(question.correctOrder);
    }
  });

  return { matching, sorting };
}

function equalSets(left: string[], right: string[]) {
  if (left.length !== right.length) {
    return false;
  }

  return left.every((item) => right.includes(item));
}

function checkMatching(question: MatchingQuestion, answers: string[]) {
  return question.pairs.reduce((sum, pair, index) => (answers[index] === pair.right ? sum + 1 : sum), 0);
}

function checkSorting(question: SortingQuestion, answers: string[]) {
  return question.correctOrder.reduce((sum, item, index) => (answers[index] === item ? sum + 1 : sum), 0);
}

function maxScore(questionId: number) {
  const question = quiz.find((item) => item.id === questionId);

  if (!question) {
    return 0;
  }

  if (question.type === 'matching') {
    return question.pairs.length;
  }

  if (question.type === 'sorting') {
    return question.correctOrder.length;
  }

  return 1;
}

function TestingPage() {
  const initialDragState = useMemo(() => createDragState(), []);
  const [matchingAnswers, setMatchingAnswers] = useState<AnswersState>(initialDragState.matching);
  const [sortingAnswers, setSortingAnswers] = useState<AnswersState>(initialDragState.sorting);
  const [singleAnswers, setSingleAnswers] = useState<SingleState>({});
  const [multipleAnswers, setMultipleAnswers] = useState<AnswersState>({});
  const [results, setResults] = useState<ResultsState | null>(null);

  const handleReset = () => {
    const newState = createDragState();
    setMatchingAnswers(newState.matching);
    setSortingAnswers(newState.sorting);
    setSingleAnswers({});
    setMultipleAnswers({});
    setResults(null);
  };

  const handleCheck = () => {
    const nextResults: ResultsState = {};

    quiz.forEach((question) => {
      if (question.type === 'matching') {
        nextResults[question.id] = checkMatching(question, matchingAnswers[question.id] || []);
      }

      if (question.type === 'sorting') {
        nextResults[question.id] = checkSorting(question, sortingAnswers[question.id] || []);
      }

      if (question.type === 'single') {
        nextResults[question.id] = singleAnswers[question.id] === question.correctAnswer ? 1 : 0;
      }

      if (question.type === 'multiple') {
        nextResults[question.id] = equalSets(multipleAnswers[question.id] || [], question.correctAnswers) ? 1 : 0;
      }
    });

    setResults(nextResults);
  };

  const totalScore = results
    ? Object.entries(results).reduce((sum, [, value]) => sum + value, 0)
    : 0;
  const totalMaxScore = quiz.reduce((sum, question) => sum + maxScore(question.id), 0);

  return (
    <main className="testing-page">
      <Container maxWidth="md">
        <Paper className="testing-card" elevation={0}>
          <Typography variant="h4" component="h1" gutterBottom>
            Проверь себя
          </Typography>
          <Typography className="testing-card__lead" paragraph>
            Тест по предметной области «Фильмы». Выполните задания на сопоставление, сортировку и выбор вариантов ответа.
          </Typography>

          <Stack spacing={4}>
            {quiz.map((question, index) => (
              <Box key={question.id} component="section" className="quiz-section">
                <Typography variant="h5" component="h2" gutterBottom>
                  {index + 1}. {question.title}
                </Typography>

                {question.type === 'matching' && (
                  <MatchingTask
                    question={question}
                    answers={matchingAnswers[question.id] || []}
                    onChange={(items) => setMatchingAnswers((state) => ({ ...state, [question.id]: items }))}
                  />
                )}

                {question.type === 'sorting' && (
                  <SortingTask
                    items={sortingAnswers[question.id] || []}
                    onChange={(items) => setSortingAnswers((state) => ({ ...state, [question.id]: items }))}
                  />
                )}

                {question.type === 'single' && (
                  <SingleChoiceTask
                    question={question}
                    value={singleAnswers[question.id] || ''}
                    onChange={(value: string) => setSingleAnswers((state) => ({ ...state, [question.id]: value }))}
                  />
                )}

                {question.type === 'multiple' && (
                  <MultipleChoiceTask
                    question={question}
                    value={multipleAnswers[question.id] || []}
                    onChange={(value: string[]) => setMultipleAnswers((state) => ({ ...state, [question.id]: value }))}
                  />
                )}
              </Box>
            ))}
          </Stack>

          <Box className="testing-actions">
            <Button variant="contained" onClick={handleCheck}>
              Проверить
            </Button>
            <Button variant="contained" color="secondary" onClick={handleReset}>
              Начать снова
            </Button>
          </Box>

          {results && (
            <Box className="results-box">
              <Typography variant="h5" component="h2" gutterBottom>
                Результаты теста
              </Typography>
              {quiz.map((question, index) => (
                <Typography key={question.id}>
                  Задание {index + 1}. Верных ответов: {results[question.id]} из {maxScore(question.id)}.
                </Typography>
              ))}
              <Typography className="results-box__total">
                Итого: {totalScore} из {totalMaxScore}.
              </Typography>
            </Box>
          )}
        </Paper>
      </Container>
    </main>
  );
}

export default TestingPage;
