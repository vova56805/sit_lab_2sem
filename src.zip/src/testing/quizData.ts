export type MatchingQuestion = {
  id: number;
  type: 'matching';
  title: string;
  pairs: {
    left: string;
    right: string;
  }[];
};

export type SortingQuestion = {
  id: number;
  type: 'sorting';
  title: string;
  correctOrder: string[];
};

export type SingleChoiceQuestion = {
  id: number;
  type: 'single';
  title: string;
  options: string[];
  correctAnswer: string;
};

export type MultipleChoiceQuestion = {
  id: number;
  type: 'multiple';
  title: string;
  options: string[];
  correctAnswers: string[];
};

export type QuizQuestion =
  | MatchingQuestion
  | SortingQuestion
  | SingleChoiceQuestion
  | MultipleChoiceQuestion;

export const quiz: QuizQuestion[] = [
  {
    id: 1,
    type: 'matching',
    title: 'Сопоставьте фильм и режиссёра.',
    pairs: [
      { left: 'Крестный отец', right: 'Фрэнсис Форд Коппола' },
      { left: 'Побег из Шоушенка', right: 'Фрэнк Дарабонт' },
      { left: 'Криминальное чтиво', right: 'Квентин Тарантино' },
      { left: 'Интерстеллар', right: 'Кристофер Нолан' }
    ]
  },
  {
    id: 2,
    type: 'matching',
    title: 'Сопоставьте фильм и год выхода.',
    pairs: [
      { left: 'Матрица', right: '1999' },
      { left: 'Титаник', right: '1997' },
      { left: 'Паразиты', right: '2019' },
      { left: 'Назад в будущее', right: '1985' }
    ]
  },
  {
    id: 3,
    type: 'sorting',
    title: 'Отсортируйте фильмы по году выхода: от самого раннего к самому позднему.',
    correctOrder: ['Крестный отец', 'Король Лев', 'Матрица', 'Интерстеллар', 'Паразиты']
  },
  {
    id: 4,
    type: 'sorting',
    title: 'Отсортируйте фильмы по рейтингу IMDb: от большего к меньшему.',
    correctOrder: ['Побег из Шоушенка', 'Крестный отец', 'Темный рыцарь', 'Криминальное чтиво', 'Бойцовский клуб']
  },
  {
    id: 5,
    type: 'single',
    title: 'Какой фильм в таблице снял Дэвид Финчер?',
    options: ['Бойцовский клуб', 'Аватар', 'Гладиатор', 'Джанго освобожденный'],
    correctAnswer: 'Бойцовский клуб'
  },
  {
    id: 6,
    type: 'multiple',
    title: 'Выберите фильмы Кристофера Нолана.',
    options: ['Темный рыцарь', 'Начало', 'Интерстеллар', 'Престиж', 'Паразиты', 'Титаник'],
    correctAnswers: ['Темный рыцарь', 'Начало', 'Интерстеллар', 'Престиж']
  }
];
