import mainHero from './assets/16305-320x240.jpg';
import sideHero from './assets/227718.jpg';
import starWarsPoster from './assets/zvezdnye-vojny-star-wars-1977-rezhissjor-dzhordzh-lukas-khudozhestvennyj-poster-k-filmu-ssha-1977-god-avtor-greg-khildebrandt-tim-khildebrandt_thumbnail.jpg';
import widePoster from './assets/300x455.png';
import orangePoster from './assets/orange.png';
import fightClubPoster from './assets/300x454.png';
import gentlemenPoster from './assets/300x452.png';
import shawshankPoster from './assets/fzpYHQqEjdiG1QTotdYisj0G-Ka-TbI4hJNtbwMGVNCiLJxKht_EqSICu6ApFnRmNWlRw5ALpiXGauERleVcYPv-eGlP0Xz5Q4ABCdFGUjcNd1kzW4zjjAH3LL420-EiUS4faBH9p1ugAH20TTKVE4DcNceQ3kJ1V6vVZrZUTiYvOy.png';
import interstellarPoster from './assets/300x451.png';
import intouchablesPoster from './assets/300x450.png';
import drivePoster from './assets/Drive2011Poster.jpg';
import type { Movie, PromoMovie } from './types';

export const heroImages = {
  main: mainHero,
  sideTop: sideHero,
  sideBottom: starWarsPoster,
  wide: widePoster
};

export const mainFeature = {
  title: 'Заводной апельсин',
  image: orangePoster,
  paragraphs: [
    'Безжалостный лидер банды подростков, совершающей убийства и изнасилования, попадает в тюрьму и подвергается специальной обработке по подавлению подсознательного стремления к насилию.',
    'Но жизнь за воротами тюрьмы такова, что меры, принятые по «исправлению жестокости характера», не могут ничего изменить.'
  ]
};

export const premiereFeature: PromoMovie = {
  title: 'Премьера',
  image: fightClubPoster,
  text: 'Сотрудник страховой компании страдает хронической бессонницей и отчаянно пытается вырваться из мучительно скучной жизни. Однажды в очередной командировке он встречает некоего Тайлера Дёрдена — харизматического торговца мылом с извращенной философией. Тайлер уверен, что самосовершенствование — удел слабых, а единственное, ради чего стоит жить, — саморазрушение. Приобщая других мужчин к простым радостям физической жестокости, они основывают тайный Бойцовский клуб.'
};

export const sidebarMovies: PromoMovie[] = [
  {
    title: 'Джентльмены',
    year: 2019,
    image: gentlemenPoster,
    text: 'Американец ещё со студенческих лет приторговывал наркотиками, но постепенно превращает это в огромную криминальную империю.'
  },
  {
    title: 'Побег из Шоушенка',
    year: 1994,
    image: shawshankPoster,
    text: 'Бухгалтер обвинён в убийстве собственной жены и её любовника, однако даже за решёткой не теряет надежду на свободу.'
  },
  {
    title: 'Интерстеллар',
    year: 2014,
    image: interstellarPoster,
    text: 'Коллектив учёных отправляется сквозь червоточину, чтобы найти человечеству новый дом.'
  },
  {
    title: '1+1',
    year: 2011,
    image: intouchablesPoster,
    text: 'Аристократ на коляске нанимает в сиделки бывшего заключённого, и эта встреча меняет жизнь обоих.'
  }
];

export const favoriteMovie = {
  title: 'Драйв',
  originalTitle: 'Drive',
  image: drivePoster,
  paragraphs: [
    '«Драйв» — американский криминальный нео-нуарный триллер с элементами боевика датского режиссёра Николаса Виндинга Рефна с Райаном Гослингом в главной роли.',
    'Картина снята по одноимённому роману Джеймса Сэллиса. Сценарий был написан Хуссейном Амини.',
    'Фильм стал победителем Каннского кинофестиваля 2011 года в номинации «Лучшая режиссура».',
    'В США фильм вышел в прокат 16 сентября 2011 года, в России — 3 ноября 2011 года.'
  ],
  facts: [
    'Год: 2011',
    'Жанр: криминал, драма, нео-нуар',
    'Режиссёр: Николас Виндинг Рефн',
    'Главная роль: Райан Гослинг'
  ]
};

export const movies: Movie[] = [
  {
    "id": 1,
    "title": "Крестный отец",
    "year": 1972,
    "genre": "Криминал, Драма",
    "director": "Фрэнсис Форд Коппола",
    "country": "США",
    "rating": 9.2,
    "duration": "175 мин"
  },
  {
    "id": 2,
    "title": "Побег из Шоушенка",
    "year": 1994,
    "genre": "Драма",
    "director": "Фрэнк Дарабонт",
    "country": "США",
    "rating": 9.3,
    "duration": "142 мин"
  },
  {
    "id": 3,
    "title": "Темный рыцарь",
    "year": 2008,
    "genre": "Боевик, Криминал",
    "director": "Кристофер Нолан",
    "country": "США, Великобритания",
    "rating": 9.0,
    "duration": "152 мин"
  },
  {
    "id": 4,
    "title": "Криминальное чтиво",
    "year": 1994,
    "genre": "Криминал, Драма",
    "director": "Квентин Тарантино",
    "country": "США",
    "rating": 8.9,
    "duration": "154 мин"
  },
  {
    "id": 5,
    "title": "Форрест Гамп",
    "year": 1994,
    "genre": "Драма, Романтика",
    "director": "Роберт Земекис",
    "country": "США",
    "rating": 8.8,
    "duration": "142 мин"
  },
  {
    "id": 6,
    "title": "Начало",
    "year": 2010,
    "genre": "Боевик, Научная фантастика",
    "director": "Кристофер Нолан",
    "country": "США, Великобритания",
    "rating": 8.8,
    "duration": "148 мин"
  },
  {
    "id": 7,
    "title": "Матрица",
    "year": 1999,
    "genre": "Боевик, Научная фантастика",
    "director": "Лана Вачовски, Лилли Вачовски",
    "country": "США",
    "rating": 8.7,
    "duration": "136 мин"
  },
  {
    "id": 8,
    "title": "Список Шиндлера",
    "year": 1993,
    "genre": "Биография, Драма",
    "director": "Стивен Спилберг",
    "country": "США",
    "rating": 8.9,
    "duration": "195 мин"
  },
  {
    "id": 9,
    "title": "Властелин колец: Возвращение короля",
    "year": 2003,
    "genre": "Приключения, Драма",
    "director": "Питер Джексон",
    "country": "Новая Зеландия, США",
    "rating": 8.9,
    "duration": "201 мин"
  },
  {
    "id": 10,
    "title": "Бойцовский клуб",
    "year": 1999,
    "genre": "Драма",
    "director": "Дэвид Финчер",
    "country": "США",
    "rating": 8.8,
    "duration": "139 мин"
  },
  {
    "id": 11,
    "title": "Зеленая книга",
    "year": 2018,
    "genre": "Биография, Комедия",
    "director": "Питер Фаррелли",
    "country": "США",
    "rating": 8.2,
    "duration": "130 мин"
  },
  {
    "id": 12,
    "title": "Паразиты",
    "year": 2019,
    "genre": "Комедия, Драма",
    "director": "Пон Джун-хо",
    "country": "Южная Корея",
    "rating": 8.6,
    "duration": "132 мин"
  },
  {
    "id": 13,
    "title": "Леон",
    "year": 1994,
    "genre": "Боевик, Драма",
    "director": "Люк Бессон",
    "country": "Франция",
    "rating": 8.5,
    "duration": "110 мин"
  },
  {
    "id": 14,
    "title": "Интерстеллар",
    "year": 2014,
    "genre": "Приключения, Драма",
    "director": "Кристофер Нолан",
    "country": "США, Великобритания",
    "rating": 8.6,
    "duration": "169 мин"
  },
  {
    "id": 15,
    "title": "Престиж",
    "year": 2006,
    "genre": "Драма, Мистика",
    "director": "Кристофер Нолан",
    "country": "США, Великобритания",
    "rating": 8.5,
    "duration": "130 мин"
  },
  {
    "id": 16,
    "title": "Пролетая над гнездом кукушки",
    "year": 1975,
    "genre": "Драма",
    "director": "Милош Форман",
    "country": "США",
    "rating": 8.7,
    "duration": "133 мин"
  },
  {
    "id": 17,
    "title": "Король Лев",
    "year": 1994,
    "genre": "Анимация, Приключения",
    "director": "Роджер Аллерс, Роб Минкофф",
    "country": "США",
    "rating": 8.5,
    "duration": "88 мин"
  },
  {
    "id": 18,
    "title": "Титаник",
    "year": 1997,
    "genre": "Драма, Романтика",
    "director": "Джеймс Кэмерон",
    "country": "США",
    "rating": 7.9,
    "duration": "195 мин"
  },
  {
    "id": 19,
    "title": "Аватар",
    "year": 2009,
    "genre": "Приключения, Научная фантастика",
    "director": "Джеймс Кэмерон",
    "country": "США",
    "rating": 7.8,
    "duration": "162 мин"
  },
  {
    "id": 20,
    "title": "Однажды в Голливуде",
    "year": 2019,
    "genre": "Комедия, Драма",
    "director": "Квентин Тарантино",
    "country": "США, Великобритания",
    "rating": 7.6,
    "duration": "161 мин"
  },
  {
    "id": 21,
    "title": "Джокер",
    "year": 2019,
    "genre": "Криминал, Драма",
    "director": "Тодд Филлипс",
    "country": "США",
    "rating": 8.4,
    "duration": "122 мин"
  },
  {
    "id": 22,
    "title": "Хороший, плохой, злой",
    "year": 1966,
    "genre": "Вестерн",
    "director": "Серджио Леоне",
    "country": "Италия",
    "rating": 8.8,
    "duration": "178 мин"
  },
  {
    "id": 23,
    "title": "Молчание ягнят",
    "year": 1991,
    "genre": "Криминал, Драма",
    "director": "Джонатан Демми",
    "country": "США",
    "rating": 8.6,
    "duration": "118 мин"
  },
  {
    "id": 24,
    "title": "Гладиатор",
    "year": 2000,
    "genre": "Боевик, Драма",
    "director": "Ридли Скотт",
    "country": "США, Великобритания",
    "rating": 8.5,
    "duration": "155 мин"
  },
  {
    "id": 25,
    "title": "Отступники",
    "year": 2006,
    "genre": "Криминал, Драма",
    "director": "Мартин Скорсезе",
    "country": "США",
    "rating": 8.5,
    "duration": "151 мин"
  },
  {
    "id": 26,
    "title": "Остров проклятых",
    "year": 2010,
    "genre": "Мистика, Триллер",
    "director": "Мартин Скорсезе",
    "country": "США",
    "rating": 8.2,
    "duration": "138 мин"
  },
  {
    "id": 27,
    "title": "ВАЛЛ-И",
    "year": 2008,
    "genre": "Анимация, Приключения",
    "director": "Эндрю Стэнтон",
    "country": "США",
    "rating": 8.4,
    "duration": "98 мин"
  },
  {
    "id": 28,
    "title": "Большой куш",
    "year": 2000,
    "genre": "Комедия, Криминал",
    "director": "Гай Ричи",
    "country": "Великобритания",
    "rating": 8.3,
    "duration": "104 мин"
  },
  {
    "id": 29,
    "title": "Зверополис",
    "year": 2016,
    "genre": "Анимация, Приключения",
    "director": "Байрон Ховард, Рич Мур",
    "country": "США",
    "rating": 8.0,
    "duration": "108 мин"
  },
  {
    "id": 30,
    "title": "Дюнкерк",
    "year": 2017,
    "genre": "Драма, Исторический",
    "director": "Кристофер Нолан",
    "country": "Нидерланды, Франция",
    "rating": 7.9,
    "duration": "106 мин"
  },
  {
    "id": 31,
    "title": "Джанго освобожденный",
    "year": 2012,
    "genre": "Драма, Вестерн",
    "director": "Квентин Тарантино",
    "country": "США",
    "rating": 8.4,
    "duration": "165 мин"
  },
  {
    "id": 32,
    "title": "Гравитация",
    "year": 2013,
    "genre": "Драма, Научная фантастика",
    "director": "Альфонсо Куарон",
    "country": "США, Великобритания",
    "rating": 7.7,
    "duration": "91 мин"
  },
  {
    "id": 33,
    "title": "Бегущий по лезвию 2049",
    "year": 2017,
    "genre": "Драма, Научная фантастика",
    "director": "Дени Вильнёв",
    "country": "США",
    "rating": 8.0,
    "duration": "164 мин"
  },
  {
    "id": 34,
    "title": "Одержимость",
    "year": 2014,
    "genre": "Драма, Музыка",
    "director": "Дэмьен Шазелл",
    "country": "США",
    "rating": 8.5,
    "duration": "107 мин"
  },
  {
    "id": 35,
    "title": "Ла-Ла Ленд",
    "year": 2016,
    "genre": "Драма, Мюзикл",
    "director": "Дэмьен Шазелл",
    "country": "США",
    "rating": 8.0,
    "duration": "128 мин"
  },
  {
    "id": 36,
    "title": "Социальная сеть",
    "year": 2010,
    "genre": "Биография, Драма",
    "director": "Дэвид Финчер",
    "country": "США",
    "rating": 7.7,
    "duration": "120 мин"
  },
  {
    "id": 37,
    "title": "Отель \"Гранд Будапешт\"",
    "year": 2014,
    "genre": "Комедия, Драма",
    "director": "Уэс Андерсон",
    "country": "США, Германия",
    "rating": 8.1,
    "duration": "99 мин"
  },
  {
    "id": 38,
    "title": "Семь",
    "year": 1995,
    "genre": "Криминал, Драма",
    "director": "Дэвид Финчер",
    "country": "США",
    "rating": 8.6,
    "duration": "127 мин"
  },
  {
    "id": 39,
    "title": "В погоне за счастьем",
    "year": 2006,
    "genre": "Биография, Драма",
    "director": "Габриеле Муччино",
    "country": "США",
    "rating": 8.0,
    "duration": "117 мин"
  },
  {
    "id": 40,
    "title": "Поймай меня, если сможешь",
    "year": 2002,
    "genre": "Биография, Криминал",
    "director": "Стивен Спилберг",
    "country": "США",
    "rating": 8.1,
    "duration": "141 мин"
  },
  {
    "id": 41,
    "title": "Игры разума",
    "year": 2001,
    "genre": "Биография, Драма",
    "director": "Рон Ховард",
    "country": "США",
    "rating": 8.2,
    "duration": "135 мин"
  },
  {
    "id": 42,
    "title": "Американская история X",
    "year": 1998,
    "genre": "Драма",
    "director": "Тони Кэй",
    "country": "США",
    "rating": 8.5,
    "duration": "119 мин"
  },
  {
    "id": 43,
    "title": "Шестое чувство",
    "year": 1999,
    "genre": "Драма, Мистика",
    "director": "М. Найт Шьямалан",
    "country": "США",
    "rating": 8.2,
    "duration": "107 мин"
  },
  {
    "id": 44,
    "title": "Спасти рядового Райана",
    "year": 1998,
    "genre": "Драма, Военный",
    "director": "Стивен Спилберг",
    "country": "США",
    "rating": 8.6,
    "duration": "169 мин"
  },
  {
    "id": 45,
    "title": "Волк с Уолл-стрит",
    "year": 2013,
    "genre": "Биография, Комедия",
    "director": "Мартин Скорсезе",
    "country": "США",
    "rating": 8.2,
    "duration": "180 мин"
  },
  {
    "id": 46,
    "title": "Терминатор 2: Судный день",
    "year": 1991,
    "genre": "Боевик, Научная фантастика",
    "director": "Джеймс Кэмерон",
    "country": "США",
    "rating": 8.6,
    "duration": "137 мин"
  },
  {
    "id": 47,
    "title": "Назад в будущее",
    "year": 1985,
    "genre": "Приключения, Комедия",
    "director": "Роберт Земекис",
    "country": "США",
    "rating": 8.5,
    "duration": "116 мин"
  },
  {
    "id": 48,
    "title": "Пианист",
    "year": 2002,
    "genre": "Биография, Драма",
    "director": "Роман Полански",
    "country": "Франция, Польша",
    "rating": 8.5,
    "duration": "150 мин"
  },
  {
    "id": 49,
    "title": "Город Бога",
    "year": 2002,
    "genre": "Криминал, Драма",
    "director": "Фернанду Мейреллиш",
    "country": "Бразилия",
    "rating": 8.6,
    "duration": "130 мин"
  },
  {
    "id": 50,
    "title": "Старикам тут не место",
    "year": 2007,
    "genre": "Криминал, Драма",
    "director": "Джоэл Коэн, Итан Коэн",
    "country": "США",
    "rating": 8.2,
    "duration": "122 мин"
  }
];
